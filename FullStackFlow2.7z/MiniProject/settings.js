const DEV_DB_URI = "mongodb+srv://jonas:koko123@cluster0-utqvq.azure.mongodb.net/miniProDevDb?retryWrites=true";
const TEST_DB_URI = "mongodb+srv://jonas:koko123@cluster0-utqvq.azure.mongodb.net/miniProTestDb?retryWrites=true";
const MOCHA_TEST_TIMEOUT = 5000;

module.exports = {
 DEV_DB_URI,
 TEST_DB_URI,
 MOCHA_TEST_TIMEOUT
}
